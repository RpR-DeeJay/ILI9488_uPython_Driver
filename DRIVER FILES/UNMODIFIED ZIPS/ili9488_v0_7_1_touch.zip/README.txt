ILI9488 MicroPython Driver - Version 0.7.1
Touch Edition
================================================

This edition includes the complete display driver plus XPT2046-compatible
touchscreen support.

Major changes
-------------
- Retains demonstrations from Versions 0.2 through 0.6
- Adds an on-screen touch menu
- Dynamically imports and unloads demonstration modules
- Adds optimized FAST paint mode
- Retains optional SMOOTH paint mode
- Preserves four-point calibration and saved calibration
- Keeps low-memory BMP, RAW and sprite handling

Paint performance
-----------------
The previous paint loop used Touch.read(samples=5), which read X, Y and
Z1 repeatedly, followed by a rounded filled-polygon thick line.

FAST mode now:
- uses T_IRQ for press detection
- reads X and Y only
- takes a three-sample median
- discards a warm-up pair only at the start of a press
- interpolates overlapping square fill_rect stamps

This substantially reduces SPI transactions and prevents most gaps when
the stylus moves quickly. The display and interpreted Python still impose
a practical speed limit, but the previous behavior was not the absolute
hardware limit.

Tap MODE in the paint header to compare FAST and SMOOTH.
Tap EXIT to return to the menu.

Touch wiring
------------
    T_CLK -> X6
    T_CS  -> X2
    T_DIN -> X8
    T_DO  -> X7
    T_IRQ -> X1

Important:
LCD SDO must remain disconnected while Touch T_DO is connected to X7.
Connecting both output pins to X7 causes bus contention and zero touch
coordinates.

LCD wiring
----------
    CS    -> X5
    RESET -> X3
    DC    -> X4
    SDI   -> X8
    SCK   -> X6
    LED   -> 3V3
    SDO   -> disconnected

Installation
------------
Copy every project file and the assets directory to the Pyboard.

Keep the generated touch_calibration.py file when upgrading from a
working Version 0.6.3 installation.

Set FORCE_CALIBRATION = True in main.py only when recalibration is needed.


Version 0.7.1 corrections
-------------------------

FAST paint import
~~~~~~~~~~~~~~~~~
Version 0.7.0 imported the private names _CMD_X and _CMD_Y from touch.py.

MicroPython may optimize const() names beginning with an underscore out
of a module's runtime global namespace. touch.py could still use the
constants internally, while:

    from touch import _CMD_X

failed with ImportError.

fast_touch.py now owns its two XPT2046 command-byte constants directly
and no longer imports private implementation details from touch.py.

Automatic calibration-file behavior
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
There is no longer a FORCE_CALIBRATION startup variable.

Startup now works as follows:

1. Check whether touch_calibration.py exists.
2. If it exists, import and validate its calibration, dimensions and
   rotation.
3. If it is absent, invalid or for another rotation, run calibration.
4. After successful calibration the generated file is used on future
   boots automatically.

Manual force recalibration remains available through the on-screen
RECALIBRATE tile. Deleting touch_calibration.py also causes automatic
calibration on the next boot.
