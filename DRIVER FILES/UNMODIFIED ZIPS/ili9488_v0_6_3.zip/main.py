"""
main.py
=======

Version 0.6.3 boot-safe, low-fragmentation touchscreen demonstration.

The display is initialized before the large graphics, touch-calibration
and demonstration modules are imported. This prevents an import-time
memory failure from leaving the ILI9488 in its blank white reset state.

Long functionality is split into smaller modules so MicroPython never
has to compile one very large source file at startup.
"""

from time import sleep_ms
import gc
import sys

from pyb import Pin, SPI

from display import Display

from colour import (
    BLACK,
    WHITE,
    RED,
    YELLOW,
    CYAN,
    DARK_BLUE,
    LIGHT_GREY,
)


DISPLAY_BAUDRATE = 10_000_000
TOUCH_BAUDRATE = 1_000_000

ROTATION = 0
FORCE_CALIBRATION = False

CALIBRATION_FILE = "touch_calibration.py"

LCD = None
GFX = None
TOUCH = None


def free_heap():
    gc.collect()

    try:
        return gc.mem_free()
    except AttributeError:
        return -1


def initialize_display():
    """
    Initialize the LCD before importing the largest project modules.
    """
    lcd_cs = Pin("X5", Pin.OUT_PP)
    lcd_dc = Pin("X4", Pin.OUT_PP)
    lcd_rst = Pin("X3", Pin.OUT_PP)

    touch_cs = Pin("X2", Pin.OUT_PP)
    touch_irq = Pin(
        "X1",
        Pin.IN,
        Pin.PULL_UP
    )

    lcd_cs.value(1)
    lcd_dc.value(1)
    lcd_rst.value(1)
    touch_cs.value(1)

    spi = SPI(
        1,
        SPI.MASTER,
        baudrate=DISPLAY_BAUDRATE,
        polarity=0,
        phase=0,
        firstbit=SPI.MSB
    )

    lcd = Display(
        spi=spi,
        cs=lcd_cs,
        dc=lcd_dc,
        rst=lcd_rst,
        width=320,
        height=480,
        rotation=ROTATION,
        debug=True,
        buffer_pixels=144
    )

    lcd.begin()

    # A dark-blue screen proves lcd.begin() completed even before the
    # graphics module has been imported.
    lcd.fill(DARK_BLUE)

    return (
        lcd,
        spi,
        lcd_cs,
        touch_cs,
        touch_irq
    )


def status(message, y=12, colour=WHITE):
    """Draw a short boot-stage status line."""
    if GFX is None:
        return

    GFX.fill_rect(
        4,
        y,
        GFX.width - 8,
        14,
        DARK_BLUE
    )

    GFX.text(
        message,
        8,
        y + 3,
        colour,
        background=DARK_BLUE
    )


def show_error(error):
    print("")
    print("Version 0.6.3 stopped:")
    try:
        sys.print_exception(error)
    except AttributeError:
        print(repr(error))

    if GFX is None:
        # The LCD was at least initialized to dark blue before any
        # optional large module import.
        return

    try:
        GFX.fill(BLACK)

        GFX.text(
            "BOOT ERROR",
            80,
            30,
            RED,
            scale=2
        )

        GFX.text(
            type(error).__name__,
            12,
            88,
            YELLOW
        )

        message = str(error)

        if not message:
            message = "See serial console."

        # Use only the already-proven basic text renderer here.
        # The layout helper itself may be the failed import.
        start = 0
        line_y = 125

        while start < len(message) and line_y < 390:
            line = message[start:start + 32]
            GFX.text(
                line,
                12,
                line_y,
                WHITE
            )
            start += 32
            line_y += 14

        heap = free_heap()

        if heap >= 0:
            GFX.text(
                "FREE HEAP: {}".format(heap),
                12,
                405,
                CYAN
            )

        GFX.text(
            "SEE SERIAL TRACEBACK",
            12,
            440,
            LIGHT_GREY
        )

    except Exception as display_error:
        print("Could not draw error:", display_error)


def main():
    global LCD
    global GFX
    global TOUCH

    print("")
    print("ILI9488 touchscreen test")
    print("Version 0.6.3")
    print("------------------------")
    print("Heap at start:", free_heap())

    (
        LCD,
        spi,
        lcd_cs,
        touch_cs,
        touch_irq
    ) = initialize_display()

    print(
        "Heap after LCD init:",
        free_heap()
    )

    # Import the proven graphics module only after the LCD is active.
    from graphics import Graphics
    GFX = Graphics(LCD)

    status(
        "DISPLAY READY",
        colour=CYAN
    )

    print(
        "Heap after graphics import:",
        free_heap()
    )

    # Touch driver is also imported after visible display startup.
    from touch import Touch

    TOUCH = Touch(
        spi=spi,
        cs=touch_cs,
        irq=touch_irq,
        display_cs=lcd_cs,
        display_baudrate=DISPLAY_BAUDRATE,
        touch_baudrate=TOUCH_BAUDRATE,
        pressure_threshold=80,
        width=LCD.width,
        height=LCD.height,
        debug=False
    )

    status(
        "TOUCH DRIVER READY",
        y=32,
        colour=CYAN
    )

    print(
        "Heap after touch import:",
        free_heap()
    )

    # Calibration code is split into smaller late-loaded modules.
    from calibration_ui import (
        load_saved,
        calibrate,
    )

    from touch import Touch as TouchClass

    if not load_saved(
        TOUCH,
        LCD.width,
        LCD.height,
        ROTATION,
        force=FORCE_CALIBRATION
    ):
        calibrate(
            GFX,
            TOUCH,
            TouchClass,
            ROTATION,
            calibration_file=CALIBRATION_FILE
        )

    print(
        "Heap after calibration:",
        free_heap()
    )

    from touch_demo import (
        transparency_test,
        run_paint,
    )

    transparency_test(
        GFX,
        LCD,
        TOUCH
    )

    run_paint(
        GFX,
        TOUCH
    )


try:
    main()

except Exception as error:
    show_error(error)
