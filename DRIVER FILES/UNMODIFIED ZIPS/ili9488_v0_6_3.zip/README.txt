ILI9488 MicroPython Library - Version 0.6.3
================================================

Version 0.6.3 fixes the Version 0.6.1 blank-white startup regression.

Cause
-----
Version 0.6.1 enlarged graphics.py, touch.py and main.py. MicroPython
must compile .py modules when importing them. On a Pyboard v1.1, the
compiler's peak heap use can fail before lcd.begin() executes. The TFT
then remains in its normal blank white reset state.

Fix
---
Version 0.6.3:

- restores the physically booting Version 0.6.0 core-module sizes
- initializes the display before importing large optional modules
- paints the display dark blue immediately after lcd.begin()
- splits wrapping, calibration logic, calibration UI and demonstrations
  into smaller source files
- imports those smaller files only after the LCD is operational
- reports import/runtime errors visibly instead of leaving a white TFT

New files
---------
    layout.py
    calibration_math.py
    calibration_ui.py
    touch_demo.py

Copy the complete project to the Pyboard. Do not mix Version 0.6.1 and
Version 0.6.3 files.

Calibration
-----------
main.py initially contains:

    FORCE_CALIBRATION = True

Complete one successful calibration, then change it to:

    FORCE_CALIBRATION = False

Four targets are collected. The strongest valid three-point combination
is selected. If a raw channel barely changes, the screen displays raw
ranges and wiring guidance instead of ending.

Touch wiring
------------
    T_CLK -> X6
    T_CS  -> X2
    T_DIN -> X8
    T_DO  -> X7
    T_IRQ -> X1

T_IRQ only detects a press. Actual X/Y coordinate data requires T_DO on
X7 and T_DIN on X8.

Transparency test
-----------------
The same sprite is drawn twice over a grid:

- left: colour key deliberately disabled, giving a magenta square
- right: magenta pixels explicitly skipped

Grid lines must remain visible through the right sprite's centre and
corners.

Project files
-------------
    main.py
    display.py
    graphics.py
    colour.py
    font8.py
    sprite.py
    bitmap.py
    touch.py
    layout.py
    calibration_math.py
    calibration_ui.py
    touch_demo.py

The assets and desktop image converter remain included.


Version 0.6.3 sprite-allocation fix
-----------------------------------
The Version 0.6.2 transparency test allocated an 88 x 88 RGB565 sprite:

    88 x 88 x 2 = 15,488 bytes

MicroPython bytearrays require one contiguous heap block. gc.mem_free()
reports total free heap, not the size of the largest contiguous block,
so allocation can fail even when 48,848 total bytes are free.

Version 0.6.3 starts with a 56 x 56 sprite requiring 6,272 bytes. It
automatically falls back to 48 x 48 or 40 x 40 if required. The sprite
is deleted immediately after both copies have been transferred to the
LCD.

FORCE_CALIBRATION now defaults to False. A saved touch_calibration.py is
loaded automatically; calibration still runs when no valid file exists.
