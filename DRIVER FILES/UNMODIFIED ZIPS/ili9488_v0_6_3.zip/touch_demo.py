"""
touch_demo.py
=============

Low-memory sprite-transparency verification and calibrated touch-paint
demonstration.

Version: 0.6.3

The Version 0.6.2 transparency sprite was 88 x 88 pixels:

    88 * 88 * 2 = 15,488 bytes

That allocation can fail on a Pyboard v1.1 even when gc.mem_free()
reports much more total free memory, because a bytearray requires one
single contiguous heap block.

Version 0.6.3:

- collects garbage immediately before sprite allocation
- starts with a proven 56 x 56 / 6,272-byte sprite
- automatically falls back to 48 x 48 or 40 x 40 if necessary
- deletes the sprite immediately after both copies are drawn
- reports heap values to the serial console
"""

from time import sleep_ms
import gc

from layout import text_box

from colour import (
    BLACK,
    WHITE,
    RED,
    GREEN,
    BLUE,
    YELLOW,
    CYAN,
    MAGENTA,
    DARK_BLUE,
    DARK_GREY,
    LIGHT_GREY,
)


def _free_heap():
    """Collect garbage and return free heap where supported."""
    gc.collect()

    try:
        return gc.mem_free()
    except AttributeError:
        return -1


def _centred_x(gfx, text, scale=1):
    """Return an x coordinate that centres fixed-font text."""
    width = gfx.text_width(
        text,
        scale=scale
    )

    return max(
        0,
        (gfx.width - width) // 2
    )


def _make_test_sprite():
    """
    Allocate the largest safe demonstration sprite from a short list.

    Returns:
        (sprite, selected_size)
    """
    # Import only when the demonstration actually begins.
    from sprite import Sprite
    from graphics import Graphics

    candidate_sizes = (
        56,
        48,
        40,
    )

    last_error = None

    for size in candidate_sizes:
        required_bytes = size * size * 2
        available = _free_heap()

        print(
            "Trying transparency sprite:",
            size,
            "x",
            size,
            "=",
            required_bytes,
            "bytes; free heap:",
            available
        )

        try:
            sprite = Sprite(
                size,
                size,
                background=MAGENTA,
                transparent=MAGENTA
            )

        except MemoryError as error:
            last_error = error

            print(
                "Allocation failed for",
                required_bytes,
                "bytes"
            )

            gc.collect()
            continue

        sprite_gfx = Graphics(sprite)

        centre = size // 2
        outer_radius = max(
            10,
            (size // 2) - 4
        )
        inner_radius = max(
            6,
            size // 4
        )

        # Only outlines are drawn. The corners and the majority of the
        # centre remain the magenta colour key.
        sprite_gfx.circle(
            centre,
            centre,
            outer_radius,
            YELLOW
        )

        sprite_gfx.circle(
            centre,
            centre,
            outer_radius - 1,
            YELLOW
        )

        sprite_gfx.circle(
            centre,
            centre,
            inner_radius,
            CYAN
        )

        sprite_gfx.circle(
            centre,
            centre,
            inner_radius - 1,
            CYAN
        )

        label = (
            "KEY"
            if size >= 48
            else "K"
        )

        label_width = sprite_gfx.text_width(label)

        sprite_gfx.text(
            label,
            max(
                0,
                (size - label_width) // 2
            ),
            max(
                0,
                centre - 4
            ),
            WHITE
        )

        print(
            "Transparency sprite created:",
            size,
            "x",
            size,
            "free heap after allocation:",
            _free_heap()
        )

        return sprite, size

    if last_error is not None:
        raise last_error

    raise MemoryError(
        "no transparency sprite size could be allocated"
    )


def transparency_test(
    gfx,
    lcd,
    touch
):
    """
    Compare the same sprite drawn opaque and colour-key transparent.
    """
    gfx.fill(BLACK)

    for x in range(0, gfx.width, 16):
        gfx.vline(
            x,
            0,
            gfx.height,
            DARK_GREY
        )

    for y in range(0, gfx.height, 16):
        gfx.hline(
            0,
            y,
            gfx.width,
            DARK_GREY
        )

    gfx.fill_rect(
        0,
        0,
        gfx.width,
        50,
        DARK_BLUE
    )

    gfx.text(
        "SPRITE TRANSPARENCY",
        _centred_x(
            gfx,
            "SPRITE TRANSPARENCY"
        ),
        14,
        WHITE,
        background=DARK_BLUE
    )

    text_box(
        gfx,
        "The same small sprite is drawn twice. Left is opaque. Right "
        "skips every magenta pixel.",
        18,
        62,
        gfx.width - 36,
        52,
        LIGHT_GREY,
        line_spacing=2,
        align="centre"
    )

    print(
        "Free heap before transparency sprite:",
        _free_heap()
    )

    sprite, sprite_size = _make_test_sprite()

    left_x = 42
    right_x = gfx.width - sprite_size - 42
    sprite_y = 165

    # Left: deliberately ignore the sprite's default colour key.
    sprite.draw(
        lcd,
        left_x,
        sprite_y,
        use_sprite_transparency=False
    )

    # Right: explicitly skip the magenta key.
    sprite.draw(
        lcd,
        right_x,
        sprite_y,
        transparent=MAGENTA,
        use_sprite_transparency=False
    )

    gfx.rect(
        left_x - 2,
        sprite_y - 2,
        sprite_size + 4,
        sprite_size + 4,
        WHITE
    )

    gfx.rect(
        right_x - 2,
        sprite_y - 2,
        sprite_size + 4,
        sprite_size + 4,
        WHITE
    )

    left_label = "OPAQUE"
    right_label = "KEYED"

    gfx.text(
        left_label,
        left_x + max(
            0,
            (sprite_size - gfx.text_width(left_label)) // 2
        ),
        sprite_y + sprite_size + 18,
        MAGENTA
    )

    gfx.text(
        right_label,
        right_x + max(
            0,
            (sprite_size - gfx.text_width(right_label)) // 2
        ),
        sprite_y + sprite_size + 18,
        GREEN
    )

    # The image is already on the physical LCD, so release the RAM
    # buffer before waiting for user input.
    del sprite
    gc.collect()

    print(
        "Free heap after transparency sprite release:",
        _free_heap()
    )

    text_box(
        gfx,
        "The left panel must contain a solid magenta square. Grid lines "
        "must remain visible through the centre and corners of the "
        "right panel. Yellow, cyan and white pixels remain opaque.",
        16,
        300,
        gfx.width - 32,
        108,
        WHITE,
        line_spacing=2,
        align="centre"
    )

    text_box(
        gfx,
        "Touch anywhere to continue.",
        20,
        445,
        gfx.width - 40,
        24,
        YELLOW,
        align="centre"
    )

    touch.wait_for_release()
    touch.wait_for_touch()
    touch.wait_for_release()


def _draw_toolbar(
    gfx,
    selected_colour
):
    """Draw the paint colour toolbar."""
    toolbar_y = gfx.height - 40
    button_width = gfx.width // 8

    colours = (
        RED,
        GREEN,
        BLUE,
        YELLOW,
        CYAN,
        MAGENTA,
        WHITE
    )

    for index, colour in enumerate(colours):
        x = index * button_width

        gfx.fill_rect(
            x,
            toolbar_y,
            button_width,
            40,
            colour
        )

        border = (
            WHITE
            if colour == selected_colour
            else DARK_GREY
        )

        thickness = (
            3
            if colour == selected_colour
            else 1
        )

        for inset in range(thickness):
            gfx.rect(
                x + inset,
                toolbar_y + inset,
                button_width - (2 * inset),
                40 - (2 * inset),
                border
            )

    clear_x = 7 * button_width

    gfx.fill_rect(
        clear_x,
        toolbar_y,
        gfx.width - clear_x,
        40,
        DARK_GREY
    )

    gfx.text(
        "CLR",
        clear_x + 7,
        toolbar_y + 16,
        WHITE
    )

    return toolbar_y, button_width, colours


def _draw_paint_screen(
    gfx,
    selected_colour
):
    """Draw the main paint screen and return toolbar geometry."""
    gfx.fill(BLACK)

    gfx.fill_rect(
        0,
        0,
        gfx.width,
        32,
        DARK_BLUE
    )

    gfx.text(
        "TOUCH PAINT",
        8,
        12,
        WHITE
    )

    gfx.text(
        "DRAG TO DRAW",
        190,
        12,
        LIGHT_GREY
    )

    gfx.hline(
        0,
        31,
        gfx.width,
        CYAN
    )

    return _draw_toolbar(
        gfx,
        selected_colour
    )


def run_paint(
    gfx,
    touch
):
    """Run the calibrated paint program indefinitely."""
    selected_colour = CYAN
    brush_radius = 4

    (
        toolbar_y,
        button_width,
        colours
    ) = _draw_paint_screen(
        gfx,
        selected_colour
    )

    previous_x = None
    previous_y = None
    was_touched = False

    print("Touch paint running; reset to exit")
    print("Free heap entering paint:", _free_heap())

    while True:
        point = touch.read(samples=5)

        if point is None:
            previous_x = None
            previous_y = None
            was_touched = False
            sleep_ms(8)
            continue

        x, y, _ = point

        if y >= toolbar_y:
            if not was_touched:
                button_index = min(
                    7,
                    x // button_width
                )

                if button_index == 7:
                    selected_colour = CYAN

                    (
                        toolbar_y,
                        button_width,
                        colours
                    ) = _draw_paint_screen(
                        gfx,
                        selected_colour
                    )
                else:
                    selected_colour = colours[
                        button_index
                    ]

                    _draw_toolbar(
                        gfx,
                        selected_colour
                    )

            previous_x = None
            previous_y = None
            was_touched = True
            sleep_ms(8)
            continue

        if y < 34:
            previous_x = None
            previous_y = None
            was_touched = True
            sleep_ms(8)
            continue

        if previous_x is None:
            gfx.fill_circle(
                x,
                y,
                brush_radius,
                selected_colour
            )
        else:
            gfx.thick_line(
                previous_x,
                previous_y,
                x,
                y,
                brush_radius * 2,
                selected_colour,
                round_caps=True
            )

        previous_x = x
        previous_y = y
        was_touched = True

        sleep_ms(6)
