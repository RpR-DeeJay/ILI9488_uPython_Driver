"""Low-level ILI9488 SPI driver for MicroPython Pyboard v1.1. Version 0.2.1."""
from time import sleep_ms
try:
    from micropython import const
except ImportError:
    def const(v): return v

_SOFTWARE_RESET=const(0x01); _SLEEP_OUT=const(0x11); _DISPLAY_ON=const(0x29)
_COLUMN_ADDRESS_SET=const(0x2A); _PAGE_ADDRESS_SET=const(0x2B); _MEMORY_WRITE=const(0x2C)
_MEMORY_ACCESS_CONTROL=const(0x36); _PIXEL_FORMAT_SET=const(0x3A)
_INTERFACE_MODE_CONTROL=const(0xB0); _FRAME_RATE_CONTROL_NORMAL=const(0xB1)
_DISPLAY_INVERSION_CONTROL=const(0xB4); _DISPLAY_FUNCTION_CONTROL=const(0xB6)
_POWER_CONTROL_1=const(0xC0); _POWER_CONTROL_2=const(0xC1); _VCOM_CONTROL_1=const(0xC5)
_POSITIVE_GAMMA_CONTROL=const(0xE0); _NEGATIVE_GAMMA_CONTROL=const(0xE1)
_ADJUST_CONTROL_3=const(0xF7); _SET_IMAGE_FUNCTION=const(0xE9)
_MADCTL_MY=const(0x80); _MADCTL_MX=const(0x40); _MADCTL_MV=const(0x20); _MADCTL_BGR=const(0x08)

class Display:
    def __init__(self, spi, cs, dc, rst, width=320, height=480, rotation=0, debug=False, buffer_pixels=256):
        self.spi=spi; self.cs=cs; self.dc=dc; self.rst=rst
        self.native_width=int(width); self.native_height=int(height)
        self.width=self.native_width; self.height=self.native_height; self.rotation=0
        self.debug=bool(debug); buffer_pixels=max(1,int(buffer_pixels))
        self._colour_buffer=bytearray(buffer_pixels*3); self._colour_buffer_view=memoryview(self._colour_buffer)
        self._single_byte=bytearray(1); self._window_buffer=bytearray(4)
        self.cs.value(1); self.dc.value(1); self.rst.value(1)
        self._requested_rotation=int(rotation)&3

    def _debug_print(self, message):
        if self.debug: print('[Display]', message)

    def _spi_write(self, data):
        try: self.spi.write(data)
        except AttributeError: self.spi.send(data)

    def _write_command(self, command, data=None):
        self.cs.value(0); self.dc.value(0); self._single_byte[0]=command&0xFF; self._spi_write(self._single_byte)
        if data is not None and len(data): self.dc.value(1); self._spi_write(data)
        self.cs.value(1)

    def _hardware_reset(self):
        self.cs.value(1); self.dc.value(1); self.rst.value(1); sleep_ms(10)
        self.rst.value(0); sleep_ms(20); self.rst.value(1); sleep_ms(150)

    def begin(self):
        self._debug_print('Beginning display initialization'); self._hardware_reset()
        self._write_command(_SOFTWARE_RESET); sleep_ms(150)
        self._write_command(_POSITIVE_GAMMA_CONTROL, bytes((0x00,0x03,0x09,0x08,0x16,0x0A,0x3F,0x78,0x4C,0x09,0x0A,0x08,0x16,0x1A,0x0F)))
        self._write_command(_NEGATIVE_GAMMA_CONTROL, bytes((0x00,0x16,0x19,0x03,0x0F,0x05,0x32,0x45,0x46,0x04,0x0E,0x0D,0x35,0x37,0x0F)))
        self._write_command(_POWER_CONTROL_1, bytes((0x17,0x15))); self._write_command(_POWER_CONTROL_2, bytes((0x41,)))
        self._write_command(_VCOM_CONTROL_1, bytes((0x00,0x12,0x80))); self._write_command(_INTERFACE_MODE_CONTROL, bytes((0x00,)))
        self._write_command(_PIXEL_FORMAT_SET, bytes((0x66,))); self._write_command(_FRAME_RATE_CONTROL_NORMAL, bytes((0xA0,)))
        self._write_command(_DISPLAY_INVERSION_CONTROL, bytes((0x02,))); self._write_command(_DISPLAY_FUNCTION_CONTROL, bytes((0x02,0x02)))
        self._write_command(_SET_IMAGE_FUNCTION, bytes((0x00,))); self._write_command(_ADJUST_CONTROL_3, bytes((0xA9,0x51,0x2C,0x82)))
        self.set_rotation(self._requested_rotation); self._write_command(_SLEEP_OUT); sleep_ms(150)
        self._write_command(_DISPLAY_ON); sleep_ms(50)
        self._debug_print('Initialization complete: {} x {}'.format(self.width,self.height))

    def set_rotation(self, rotation):
        rotation=int(rotation)&3; self.rotation=rotation
        if rotation==0: madctl=_MADCTL_MX|_MADCTL_BGR; self.width=self.native_width; self.height=self.native_height
        elif rotation==1: madctl=_MADCTL_MV|_MADCTL_BGR; self.width=self.native_height; self.height=self.native_width
        elif rotation==2: madctl=_MADCTL_MY|_MADCTL_BGR; self.width=self.native_width; self.height=self.native_height
        else: madctl=_MADCTL_MX|_MADCTL_MY|_MADCTL_MV|_MADCTL_BGR; self.width=self.native_height; self.height=self.native_width
        self._write_command(_MEMORY_ACCESS_CONTROL, bytes((madctl,)))

    def set_window(self,x0,y0,x1,y1):
        b=self._window_buffer
        b[0]=(x0>>8)&255; b[1]=x0&255; b[2]=(x1>>8)&255; b[3]=x1&255; self._write_command(_COLUMN_ADDRESS_SET,b)
        b[0]=(y0>>8)&255; b[1]=y0&255; b[2]=(y1>>8)&255; b[3]=y1&255; self._write_command(_PAGE_ADDRESS_SET,b)

    @staticmethod
    def _rgb565_to_rgb666(c):
        c&=0xFFFF; r=(c>>11)&31; g=(c>>5)&63; b=c&31
        return (((r<<3)|(r>>2))&0xFC, ((g<<2)|(g>>4))&0xFC, ((b<<3)|(b>>2))&0xFC)

    def _prepare_colour_buffer(self,c):
        r,g,b=self._rgb565_to_rgb666(c); data=self._colour_buffer
        for i in range(0,len(data),3): data[i]=r; data[i+1]=g; data[i+2]=b

    def _write_repeated_colour(self,c,count):
        count=int(count)
        if count<=0: return
        self._prepare_colour_buffer(c); ppb=len(self._colour_buffer)//3
        full=count//ppb; rem=count%ppb
        self.cs.value(0); self.dc.value(0); self._single_byte[0]=_MEMORY_WRITE; self._spi_write(self._single_byte); self.dc.value(1)
        for _ in range(full): self._spi_write(self._colour_buffer)
        if rem: self._spi_write(self._colour_buffer_view[:rem*3])
        self.cs.value(1)

    def fill(self,c): self.fill_rect(0,0,self.width,self.height,c)

    def fill_rect(self,x,y,w,h,c):
        x=int(x); y=int(y); w=int(w); h=int(h)
        if w<=0 or h<=0: return
        x1=x+w-1; y1=y+h-1
        if x>=self.width or y>=self.height or x1<0 or y1<0: return
        if x<0: x=0
        if y<0: y=0
        if x1>=self.width: x1=self.width-1
        if y1>=self.height: y1=self.height-1
        self.set_window(x,y,x1,y1); self._write_repeated_colour(c,(x1-x+1)*(y1-y+1))

    def pixel(self,x,y,c):
        x=int(x); y=int(y)
        if 0<=x<self.width and 0<=y<self.height:
            self.set_window(x,y,x,y); self._write_repeated_colour(c,1)

    def hline(self,x,y,length,c): self.fill_rect(x,y,length,1,c)
    def vline(self,x,y,length,c): self.fill_rect(x,y,1,length,c)
