"""
main.py
=======

Version 0.4.1 advanced-graphics test for the MicroPython Pyboard v1.1
and ILI9488 480 x 320 SPI TFT.

New in Version 0.4.1
--------------------
- ellipses
- rounded rectangles
- polygons
- regular polygons
- thick lines
- circular arcs
- RGB565 gradients
- gradients clipped to rounded rectangles

The Version 0.3.0 text functions and all earlier graphics primitives
remain available.
"""

from time import sleep_ms
from pyb import Pin, SPI

from display import Display
from graphics import Graphics

from colour import (
    BLACK,
    WHITE,
    RED,
    GREEN,
    BLUE,
    YELLOW,
    CYAN,
    MAGENTA,
    ORANGE,
    PURPLE,
    DARK_BLUE,
    DARK_GREEN,
    DARK_GREY,
    LIGHT_GREY
)

SPI_BAUDRATE = 10_000_000
DEBUG = True
ROTATION = 0


def create_display():
    cs = Pin("X5", Pin.OUT_PP)
    dc = Pin("X4", Pin.OUT_PP)
    rst = Pin("X3", Pin.OUT_PP)

    cs.value(1)
    dc.value(1)
    rst.value(1)

    spi = SPI(
        1,
        SPI.MASTER,
        baudrate=SPI_BAUDRATE,
        polarity=0,
        phase=0,
        firstbit=SPI.MSB
    )

    lcd = Display(
        spi=spi,
        cs=cs,
        dc=dc,
        rst=rst,
        width=320,
        height=480,
        rotation=ROTATION,
        debug=DEBUG,
        buffer_pixels=256
    )

    lcd.begin()
    return lcd


def test_ellipses(gfx):
    gfx.fill(BLACK)
    gfx.text("ELLIPSES", 8, 8, WHITE, background=DARK_BLUE, scale=2)

    gfx.fill_ellipse(90, 120, 70, 35, BLUE)
    gfx.ellipse(90, 120, 70, 35, CYAN)

    gfx.fill_ellipse(230, 120, 35, 70, DARK_GREEN)
    gfx.ellipse(230, 120, 35, 70, GREEN)

    gfx.ellipse(160, 285, 140, 75, MAGENTA)
    gfx.ellipse(160, 285, 105, 52, YELLOW)
    gfx.ellipse(160, 285, 70, 30, WHITE)

    sleep_ms(3200)


def test_round_rects_and_gradients(gfx):
    gfx.gradient_rect(0, 0, gfx.width, gfx.height, DARK_BLUE, BLACK, True)
    gfx.text("ROUNDED RECTANGLES", 8, 8, WHITE, scale=1)

    gfx.fill_round_rect(20, 48, 280, 72, 18, BLUE)
    gfx.round_rect(20, 48, 280, 72, 18, CYAN)
    gfx.text("FILLED ROUND RECT", 48, 74, WHITE, scale=1)

    gfx.gradient_round_rect(
        30,
        155,
        260,
        90,
        22,
        RED,
        YELLOW,
        vertical=False
    )
    gfx.round_rect(30, 155, 260, 90, 22, WHITE)
    gfx.text("HORIZONTAL GRADIENT", 57, 195, BLACK, scale=1)

    gfx.gradient_round_rect(
        55,
        285,
        210,
        120,
        28,
        CYAN,
        PURPLE,
        vertical=True
    )
    gfx.round_rect(55, 285, 210, 120, 28, WHITE)
    gfx.text("VERTICAL", 116, 328, WHITE, scale=1)
    gfx.text("GRADIENT", 112, 352, WHITE, scale=1)

    sleep_ms(3500)


def test_polygons(gfx):
    gfx.fill(BLACK)
    gfx.text("POLYGONS", 8, 8, YELLOW, scale=2)

    concave = (
        (25, 95),
        (105, 65),
        (88, 135),
        (135, 180),
        (72, 174),
        (35, 230)
    )
    gfx.fill_polygon(concave, BLUE)
    gfx.polygon(concave, CYAN)

    gfx.regular_polygon(230, 130, 72, 5, RED, rotation=270, fill=True)
    gfx.regular_polygon(230, 130, 72, 5, YELLOW, rotation=270, fill=False)

    for sides in range(3, 9):
        x = 35 + ((sides - 3) * 48)
        gfx.regular_polygon(x, 330, 20, sides, GREEN, rotation=270, fill=False)

    gfx.text("3  4  5  6  7  8 SIDES", 16, 365, WHITE, scale=1)

    sleep_ms(3500)


def test_thick_lines_and_arcs(gfx):
    gfx.fill(DARK_GREY)
    gfx.text("THICK LINES + ARCS", 8, 8, WHITE, scale=1)

    colours = (RED, ORANGE, YELLOW, GREEN, CYAN, BLUE, MAGENTA)

    for index, thickness in enumerate((2, 4, 6, 8, 10, 12, 14)):
        y = 48 + (index * 30)
        gfx.thick_line(24, y, 292, y + 18, thickness, colours[index], True)

    centre_x = gfx.width // 2
    centre_y = 350

    gfx.arc(centre_x, centre_y, 92, 180, 360, CYAN, thickness=2, step=3)
    gfx.arc(centre_x, centre_y, 72, 200, 340, YELLOW, thickness=5, step=3)
    gfx.arc(centre_x, centre_y, 50, 220, 320, RED, thickness=9, step=3)
    gfx.fill_circle(centre_x, centre_y, 7, WHITE)

    sleep_ms(3800)


def test_transparent_text_overlap(gfx):
    """Corrected Version 0.3 transparency demonstration."""
    gfx.fill(BLACK)

    centre_x = gfx.width // 2
    centre_y = gfx.height // 2

    for radius in range(145, 20, -18):
        colour = CYAN if (radius // 18) & 1 else BLUE
        gfx.circle(centre_x, centre_y, radius, colour)

    # This now passes directly through the circles instead of sitting
    # above them, making the transparent background obvious.
    gfx.text(
        "TRANSPARENT",
        61,
        centre_y - 16,
        YELLOW,
        background=None,
        scale=2
    )

    gfx.text(
        "SOLID BACKGROUND",
        16,
        centre_y + 38,
        WHITE,
        background=RED,
        scale=2
    )

    gfx.text(
        "Circle lines remain visible between the yellow letter pixels.",
        12,
        centre_y + 100,
        LIGHT_GREY,
        wrap=True,
        line_spacing=2
    )

    sleep_ms(3500)


def final_screen(gfx):
    gfx.gradient_rect(0, 0, gfx.width, gfx.height, DARK_BLUE, BLACK, True)

    gfx.round_rect(5, 5, gfx.width - 10, gfx.height - 10, 18, CYAN)
    gfx.text("ILI9488 LIBRARY", 32, 24, WHITE, background=DARK_BLUE, scale=2)
    gfx.text("VERSION 0.4.1", 60, 64, YELLOW, scale=1)

    centre_x = gfx.width // 2
    centre_y = 205

    gfx.arc(centre_x, centre_y, 100, 195, 345, CYAN, thickness=5, step=3)
    gfx.arc(centre_x, centre_y, 78, 210, 330, MAGENTA, thickness=4, step=3)
    gfx.fill_ellipse(centre_x, centre_y, 54, 34, BLUE)
    gfx.ellipse(centre_x, centre_y, 54, 34, WHITE)
    gfx.regular_polygon(centre_x, centre_y, 29, 6, YELLOW, rotation=270, fill=True)
    gfx.regular_polygon(centre_x, centre_y, 29, 6, WHITE, rotation=270, fill=False)

    gfx.fill_round_rect(42, 330, 236, 62, 16, DARK_GREY)
    gfx.round_rect(42, 330, 236, 62, 16, GREEN)
    gfx.text("ADVANCED GRAPHICS", 70, 352, GREEN, scale=1)

    gfx.text("READY FOR V0.5.0", 74, 420, WHITE, scale=1)
    print("Version 0.4.1 graphics test complete")


def main():
    print("")
    print("ILI9488 advanced graphics test")
    print("Version 0.4.1")
    print("-------------------------------")

    lcd = create_display()
    gfx = Graphics(lcd)

    print("Testing ellipses")
    test_ellipses(gfx)

    print("Testing rounded rectangles and gradients")
    test_round_rects_and_gradients(gfx)

    print("Testing polygons")
    test_polygons(gfx)

    print("Testing thick lines and arcs")
    test_thick_lines_and_arcs(gfx)

    print("Testing transparent text overlap")
    test_transparent_text_overlap(gfx)

    print("Drawing final screen")
    final_screen(gfx)


try:
    main()
except Exception as error:
    print("")
    print("Advanced graphics test failed:")
    print(error)
    raise
