ILI9488 MicroPython Driver - Version 0.7.0
Display-Only Edition
================================================

This edition provides the complete display, graphics, text, image and
sprite driver without touchscreen functionality.

It does not import touch.py and does not require:
- T_CS
- T_IRQ
- T_DIN
- T_DO
- any calibration file

LCD wiring
----------
    VCC   -> 3V3
    GND   -> GND
    CS    -> X5
    RESET -> X3
    DC    -> X4
    SDI   -> X8 / SPI1 MOSI
    SCK   -> X6 / SPI1 SCK
    LED   -> 3V3

LCD SDO is optional and may remain disconnected because this driver is
write-only.

Included capabilities
---------------------
- Four display rotations
- RGB565 public colours and RGB666 ILI9488 transfer
- Pixels and clipped fills
- Lines, rectangles, circles and triangles
- Ellipses and rounded rectangles
- Arbitrary and regular polygons
- Thick lines and arcs
- Rectangular and rounded gradients
- Printable ASCII text
- Scaling, transparent text and bounded wrapping
- RGB565 sprites and colour-key transparency
- BMP and RAW row-streaming
- Image and sprite cropping

The complete retained demonstration suite runs automatically.
