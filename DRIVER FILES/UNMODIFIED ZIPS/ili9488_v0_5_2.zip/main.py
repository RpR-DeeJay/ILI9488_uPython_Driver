"""
main.py
=======

Version 0.5.2 low-memory image-and-sprite demonstration for the
MicroPython Pyboard v1.1 and ILI9488 SPI TFT.

Why this release exists
-----------------------
Version 0.5.1 removed the large temporary sprite allocation, but its
first demonstration sprite could still require a contiguous allocation
larger than the remaining Pyboard heap after graphics.py was imported.

Version 0.5.2 therefore:

- uses substantially smaller demonstration sprites
- shows progress directly on the TFT
- prints free heap before and after every sprite allocation
- catches and displays MemoryError and other exceptions on the TFT
- keeps streamed BMP and RAW demonstrations
- proves sprite cropping, transparency and repeated blitting using
  buffers sized appropriately for a Pyboard v1.1

Copy the complete project, including the assets directory, to the
Pyboard filesystem. Wiring is unchanged.
"""

from time import sleep_ms
import gc
import sys

from pyb import Pin, SPI

from display import Display
from graphics import Graphics
from sprite import Sprite

from colour import (
    BLACK,
    WHITE,
    RED,
    GREEN,
    BLUE,
    YELLOW,
    CYAN,
    MAGENTA,
    ORANGE,
    PURPLE,
    DARK_BLUE,
    DARK_GREY,
    LIGHT_GREY
)


SPI_BAUDRATE = 10_000_000
DEBUG = True
ROTATION = 0

DEMO_BMP = "assets/demo.bmp"
DEMO_RAW = "assets/demo.raw"
DEMO_WIDTH = 120
DEMO_HEIGHT = 80

LCD = None
GFX = None


def free_heap():
    """
    Collect garbage and return free heap where MicroPython provides it.
    """
    gc.collect()

    try:
        return gc.mem_free()
    except AttributeError:
        return -1


def report_memory(label):
    """Print one free-heap checkpoint."""
    available = free_heap()

    if available >= 0:
        print(
            label,
            "- free heap:",
            available,
            "bytes"
        )
    else:
        print(label)

    return available


def status(gfx, message, y=38, colour=LIGHT_GREY):
    """
    Replace a single-line status message near the top of the display.
    """
    gfx.fill_rect(
        4,
        y,
        gfx.width - 8,
        12,
        DARK_BLUE
    )

    gfx.text(
        message,
        8,
        y + 2,
        colour,
        background=DARK_BLUE,
        scale=1
    )


def centred_x(gfx, text, scale=1, spacing=1):
    """Return an x coordinate that centres text."""
    width = gfx.text_width(
        text,
        scale=scale,
        spacing=spacing
    )

    return max(0, (gfx.width - width) // 2)


def create_display():
    """Initialize SPI1 and the physical display."""
    cs = Pin("X5", Pin.OUT_PP)
    dc = Pin("X4", Pin.OUT_PP)
    rst = Pin("X3", Pin.OUT_PP)

    cs.value(1)
    dc.value(1)
    rst.value(1)

    spi = SPI(
        1,
        SPI.MASTER,
        baudrate=SPI_BAUDRATE,
        polarity=0,
        phase=0,
        firstbit=SPI.MSB
    )

    lcd = Display(
        spi=spi,
        cs=cs,
        dc=dc,
        rst=rst,
        width=320,
        height=480,
        rotation=ROTATION,
        debug=DEBUG,
        buffer_pixels=160
    )

    lcd.begin()
    return lcd


def draw_page_header(gfx, title):
    """Draw a consistent demonstration-page heading."""
    gfx.gradient_rect(
        0,
        0,
        gfx.width,
        gfx.height,
        DARK_BLUE,
        BLACK,
        vertical=True
    )

    gfx.text(
        title,
        centred_x(gfx, title),
        10,
        WHITE,
        background=DARK_BLUE,
        scale=1
    )


def draw_grid(gfx, spacing=20):
    """Draw a background that makes transparency obvious."""
    for x in range(0, gfx.width, spacing):
        gfx.vline(
            x,
            0,
            gfx.height,
            DARK_GREY
        )

    for y in range(0, gfx.height, spacing):
        gfx.hline(
            0,
            y,
            gfx.width,
            DARK_GREY
        )


def make_opaque_sprite():
    """
    Create a 64 x 48 sprite requiring 6,144 bytes.
    """
    required = Sprite.required_bytes(64, 48)

    report_memory(
        "Before opaque sprite allocation ({})".format(required)
    )

    sprite = Sprite(
        64,
        48,
        background=DARK_BLUE
    )

    gfx = Graphics(sprite)

    gfx.gradient_round_rect(
        1,
        1,
        62,
        46,
        9,
        BLUE,
        PURPLE,
        vertical=False
    )

    gfx.round_rect(
        1,
        1,
        62,
        46,
        9,
        CYAN
    )

    gfx.fill_circle(
        17,
        24,
        12,
        ORANGE
    )

    gfx.circle(
        17,
        24,
        12,
        WHITE
    )

    gfx.text(
        "SP",
        36,
        12,
        WHITE
    )

    gfx.text(
        "565",
        33,
        29,
        YELLOW
    )

    report_memory("After opaque sprite creation")
    return sprite


def make_transparent_sprite():
    """
    Create a 56 x 56 sprite requiring 6,272 bytes.
    """
    required = Sprite.required_bytes(56, 56)

    report_memory(
        "Before transparent sprite allocation ({})".format(required)
    )

    sprite = Sprite(
        56,
        56,
        background=MAGENTA,
        transparent=MAGENTA
    )

    gfx = Graphics(sprite)

    gfx.regular_polygon(
        28,
        28,
        25,
        5,
        YELLOW,
        rotation=270,
        fill=True
    )

    gfx.regular_polygon(
        28,
        28,
        25,
        5,
        WHITE,
        rotation=270,
        fill=False
    )

    gfx.fill_circle(
        28,
        28,
        12,
        BLUE
    )

    gfx.circle(
        28,
        28,
        12,
        CYAN
    )

    return sprite


def test_opaque_sprites(gfx, lcd):
    """Test complete sprites, source cropping and edge clipping."""
    draw_page_header(gfx, "OFF-SCREEN SPRITES")
    status(gfx, "Allocating 64 x 48 sprite...")

    sprite = make_opaque_sprite()

    status(
        gfx,
        "Sprite ready: {} bytes".format(
            sprite.memory_bytes
        ),
        colour=GREEN
    )

    sprite.draw(lcd, 24, 82)
    sprite.draw(lcd, 128, 82)
    sprite.draw(lcd, 232, 82)

    gfx.text("FULL", 40, 142, GREEN)
    gfx.text("FULL", 144, 142, GREEN)
    gfx.text("FULL", 248, 142, GREEN)

    # Crop a 40 x 30 region from the same sprite.
    sprite.draw(
        lcd,
        35,
        220,
        source_x=12,
        source_y=8,
        width=40,
        height=30
    )

    gfx.rect(
        34,
        219,
        42,
        32,
        WHITE
    )

    gfx.text(
        "CROP",
        37,
        264,
        YELLOW
    )

    # Deliberately clip against the right screen edge.
    sprite.draw(
        lcd,
        286,
        220
    )

    gfx.text(
        "EDGE CLIP",
        222,
        286,
        CYAN
    )

    gfx.text(
        "The same 6 KB buffer has been drawn five times.",
        16,
        350,
        LIGHT_GREY,
        wrap=True
    )

    del sprite
    report_memory("After opaque sprite release")

    sleep_ms(3200)


def test_transparent_sprites(gfx, lcd):
    """Show RGB565 colour-key transparency over a grid."""
    gfx.fill(BLACK)
    draw_grid(gfx, 18)

    title = "TRANSPARENT SPRITES"

    gfx.text(
        title,
        centred_x(gfx, title),
        10,
        WHITE,
        background=DARK_BLUE,
        scale=1
    )

    status(gfx, "Allocating 56 x 56 sprite...")

    sprite = make_transparent_sprite()

    status(
        gfx,
        "Magenta colour-key enabled",
        colour=GREEN
    )

    sprite.draw(lcd, 24, 90)
    sprite.draw(lcd, 132, 180)
    sprite.draw(lcd, 240, 270)

    gfx.text(
        "GRID REMAINS VISIBLE",
        74,
        360,
        YELLOW
    )

    gfx.text(
        "Only non-magenta runs are sent to the display.",
        18,
        405,
        LIGHT_GREY,
        wrap=True
    )

    del sprite
    report_memory("After transparent sprite release")

    sleep_ms(3400)


def test_bitmap_files(gfx, lcd):
    """Render complete and cropped BMP/RAW files by streaming rows."""
    status(gfx, "Importing bitmap module...")

    from bitmap import draw_bmp, draw_raw

    report_memory("After importing bitmap module")

    draw_page_header(gfx, "BMP + RAW STREAMING")
    status(gfx, "Reading one visible row at a time")

    draw_bmp(
        lcd,
        DEMO_BMP,
        20,
        65
    )

    draw_raw(
        lcd,
        DEMO_RAW,
        DEMO_WIDTH,
        DEMO_HEIGHT,
        180,
        65,
        byteorder="big"
    )

    gfx.rect(
        19,
        64,
        DEMO_WIDTH + 2,
        DEMO_HEIGHT + 2,
        WHITE
    )

    gfx.rect(
        179,
        64,
        DEMO_WIDTH + 2,
        DEMO_HEIGHT + 2,
        WHITE
    )

    gfx.text("24-BIT BMP", 39, 156, CYAN)
    gfx.text("RGB565 RAW", 195, 156, YELLOW)

    draw_bmp(
        lcd,
        DEMO_BMP,
        35,
        230,
        source_x=25,
        source_y=15,
        width=70,
        height=50
    )

    draw_raw(
        lcd,
        DEMO_RAW,
        DEMO_WIDTH,
        DEMO_HEIGHT,
        215,
        230,
        source_x=25,
        source_y=15,
        width=70,
        height=50,
        byteorder="big"
    )

    gfx.rect(34, 229, 72, 52, WHITE)
    gfx.rect(214, 229, 72, 52, WHITE)

    gfx.text(
        "CROPPED WITHOUT FULL IMAGE BUFFER",
        23,
        305,
        GREEN
    )

    gfx.text(
        "Streaming is the preferred method for pictures larger than "
        "small icons or repeated sprites.",
        16,
        355,
        LIGHT_GREY,
        wrap=True,
        line_spacing=2
    )

    report_memory("After streamed image test")
    sleep_ms(3600)


def test_bitmap_loaded_as_sprite(gfx, lcd):
    """
    Load a 48 x 32 BMP crop as a small reusable sprite.
    """
    from bitmap import load_bmp_sprite

    draw_page_header(gfx, "BMP AS SMALL SPRITE")
    status(gfx, "Loading 48 x 32 crop: 3072 bytes")

    report_memory("Before loading BMP crop")

    sprite = load_bmp_sprite(
        DEMO_BMP,
        source_x=36,
        source_y=24,
        width=48,
        height=32
    )

    report_memory("After loading BMP crop")

    positions = (
        (28, 90),
        (136, 90),
        (244, 90),
        (28, 190),
        (136, 190),
        (244, 190)
    )

    for x, y in positions:
        sprite.draw(lcd, x, y)
        gfx.rect(
            x - 1,
            y - 1,
            sprite.width + 2,
            sprite.height + 2,
            WHITE
        )

    gfx.text(
        "ONE 3 KB SPRITE, SIX BLITS",
        49,
        285,
        YELLOW
    )

    gfx.text(
        "Use sprites for compact graphics that must be redrawn often.",
        16,
        340,
        WHITE,
        wrap=True,
        line_spacing=2
    )

    del sprite
    report_memory("After BMP sprite release")

    sleep_ms(3400)


def final_screen(gfx, lcd):
    """Leave a combined image-and-sprite demonstration visible."""
    from bitmap import draw_bmp

    gfx.gradient_rect(
        0,
        0,
        gfx.width,
        gfx.height,
        DARK_BLUE,
        BLACK,
        vertical=True
    )

    gfx.round_rect(
        5,
        5,
        gfx.width - 10,
        gfx.height - 10,
        18,
        CYAN
    )

    title = "ILI9488 LIBRARY"

    gfx.text(
        title,
        centred_x(gfx, title, scale=2),
        22,
        WHITE,
        background=DARK_BLUE,
        scale=2
    )

    gfx.text(
        "VERSION 0.5.2",
        60,
        60,
        YELLOW
    )

    draw_bmp(
        lcd,
        DEMO_BMP,
        100,
        100
    )

    sprite = make_transparent_sprite()
    sprite.draw(lcd, 132, 220)

    gfx.text(
        "BMP + RAW + SPRITES",
        64,
        315,
        GREEN
    )

    gfx.text(
        "LOW-MEMORY PYBOARD BUILD",
        54,
        370,
        WHITE
    )

    del sprite
    report_memory("Final free heap")

    print("Version 0.5.2 image and sprite test complete")


def show_error(error):
    """
    Present an exception on both the serial console and the TFT.
    """
    print("")
    print("Version 0.5.2 stopped with an exception:")

    try:
        sys.print_exception(error)
    except AttributeError:
        print(repr(error))

    if GFX is None:
        return

    try:
        GFX.fill(BLACK)

        GFX.text(
            "SCRIPT ERROR",
            52,
            30,
            RED,
            scale=2
        )

        error_name = type(error).__name__

        GFX.text(
            error_name,
            12,
            90,
            YELLOW,
            scale=1
        )

        message = str(error)

        if not message:
            message = "No exception message was supplied."

        GFX.text(
            message,
            12,
            125,
            WHITE,
            wrap=True,
            line_spacing=2
        )

        available = free_heap()

        if available >= 0:
            GFX.text(
                "FREE HEAP: {} BYTES".format(available),
                12,
                390,
                CYAN
            )

        GFX.text(
            "See serial console for traceback.",
            12,
            430,
            LIGHT_GREY
        )

    except Exception as display_error:
        print("Could not display the error:", display_error)


def main():
    global LCD
    global GFX

    print("")
    print("ILI9488 image and sprite test")
    print("Version 0.5.2")
    print("--------------------------------")

    report_memory("At program start")

    LCD = create_display()
    GFX = Graphics(LCD)

    report_memory("After display initialization")

    print("Testing opaque off-screen sprites")
    test_opaque_sprites(GFX, LCD)

    print("Testing transparent sprites")
    test_transparent_sprites(GFX, LCD)

    print("Testing streamed BMP and RAW files")
    test_bitmap_files(GFX, LCD)

    print("Testing BMP loaded into a sprite")
    test_bitmap_loaded_as_sprite(GFX, LCD)

    print("Drawing final screen")
    final_screen(GFX, LCD)


try:
    main()

except Exception as error:
    show_error(error)
