ILI9488 MicroPython Library - Version 0.5.2
================================================

Copy these files to the Pyboard filesystem root:

    main.py
    display.py
    graphics.py
    colour.py
    font8.py
    sprite.py
    bitmap.py

Also copy the complete assets directory:

    assets/demo.bmp
    assets/demo.raw

The tools directory is for a desktop PC and does not need to be copied
to the Pyboard:

    tools/image_converter.py

Demo asset dimensions:

    demo.bmp: 120 x 80
    demo.raw: 120 x 80, big-endian RGB565

Primary APIs:

    display.blit_rgb565(...)
    Sprite(...)
    sprite.draw(...)
    draw_bmp(...)
    draw_raw(...)
    load_bmp_sprite(...)

The display wiring remains unchanged from Version 0.4.1.


Version 0.5.2 memory fix
------------------------
Version 0.5.0 initialized a sprite by creating its final bytearray and
then creating a second full-size temporary bytes object to fill it.
That temporary could exhaust or fragment the Pyboard heap.

Version 0.5.2 fills sprite storage in place, uses smaller demonstration
sprites, delays importing bitmap.py, and prints free-heap checkpoints.


Version 0.5.2 low-memory physical test
--------------------------------------
The first opaque sprite is now 64 x 48 pixels, requiring 6,144 bytes.
The transparent sprite is 56 x 56 pixels, requiring 6,272 bytes.
The BMP sprite test loads only a 48 x 32 crop, requiring 3,072 bytes.

The demonstration writes progress messages directly onto the TFT. Any
caught exception is also shown on the TFT, so an apparent silent stop
should now report its exception type and message.
